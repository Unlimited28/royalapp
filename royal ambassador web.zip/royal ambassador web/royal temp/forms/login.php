$_SESSION['user_id'] = $user['id'];
$_SESSION['full_name'] = $user['full_name'];
$_SESSION['email'] = $user['email'];
$_SESSION['avatar'] = $user['avatar']; // Store avatar path
// add more as needed